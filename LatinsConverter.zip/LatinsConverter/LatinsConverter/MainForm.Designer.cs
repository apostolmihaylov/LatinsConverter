﻿/*
 * Created by SharpDevelop.
 * User: root
 * Date: 1/8/2021
 * Time: 11:24 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace LatinsConverter
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.RichTextBox richTextBoxSpecialLetters;
		private System.Windows.Forms.RichTextBox richTextBoxLatinLetters;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button buttonConvert;
		private System.Windows.Forms.Button buttonCopy;
		private System.Windows.Forms.Label labelPrint;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
		private System.Windows.Forms.Label labelSymbolsModifies;
		private System.Windows.Forms.Button buttonViewUnicode;
		private System.Windows.Forms.TextBox textBoxViewUnicode;
		private System.Windows.Forms.Label labelUnicodeInfo;
		private System.Windows.Forms.CheckBox checkBoxRemoveDoubleSpace;
		private System.Windows.Forms.CheckBox checkBoxToUpperCase;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.richTextBoxSpecialLetters = new System.Windows.Forms.RichTextBox();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.richTextBoxLatinLetters = new System.Windows.Forms.RichTextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.buttonConvert = new System.Windows.Forms.Button();
			this.buttonCopy = new System.Windows.Forms.Button();
			this.labelPrint = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.labelSymbolsModifies = new System.Windows.Forms.Label();
			this.buttonViewUnicode = new System.Windows.Forms.Button();
			this.textBoxViewUnicode = new System.Windows.Forms.TextBox();
			this.labelUnicodeInfo = new System.Windows.Forms.Label();
			this.checkBoxRemoveDoubleSpace = new System.Windows.Forms.CheckBox();
			this.checkBoxToUpperCase = new System.Windows.Forms.CheckBox();
			this.contextMenuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// richTextBoxSpecialLetters
			// 
			this.richTextBoxSpecialLetters.ContextMenuStrip = this.contextMenuStrip1;
			this.richTextBoxSpecialLetters.Location = new System.Drawing.Point(25, 48);
			this.richTextBoxSpecialLetters.Name = "richTextBoxSpecialLetters";
			this.richTextBoxSpecialLetters.Size = new System.Drawing.Size(671, 195);
			this.richTextBoxSpecialLetters.TabIndex = 1;
			this.richTextBoxSpecialLetters.Text = "";
			this.richTextBoxSpecialLetters.TextChanged += new System.EventHandler(this.RichTextBoxSpecialLettersTextChanged);
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.pasteToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(103, 26);
			// 
			// pasteToolStripMenuItem
			// 
			this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
			this.pasteToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
			this.pasteToolStripMenuItem.Text = "Paste";
			this.pasteToolStripMenuItem.Click += new System.EventHandler(this.PasteToolStripMenuItemClick);
			// 
			// richTextBoxLatinLetters
			// 
			this.richTextBoxLatinLetters.Location = new System.Drawing.Point(25, 342);
			this.richTextBoxLatinLetters.Name = "richTextBoxLatinLetters";
			this.richTextBoxLatinLetters.ReadOnly = true;
			this.richTextBoxLatinLetters.Size = new System.Drawing.Size(671, 196);
			this.richTextBoxLatinLetters.TabIndex = 2;
			this.richTextBoxLatinLetters.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(25, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(306, 23);
			this.label1.TabIndex = 3;
			this.label1.Text = "Text with special letters";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(25, 316);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(306, 23);
			this.label2.TabIndex = 4;
			this.label2.Text = "Text with latin letters";
			// 
			// buttonConvert
			// 
			this.buttonConvert.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.buttonConvert.Location = new System.Drawing.Point(713, 48);
			this.buttonConvert.Name = "buttonConvert";
			this.buttonConvert.Size = new System.Drawing.Size(149, 44);
			this.buttonConvert.TabIndex = 5;
			this.buttonConvert.Text = "Convert To Latin";
			this.buttonConvert.UseVisualStyleBackColor = false;
			this.buttonConvert.Click += new System.EventHandler(this.ButtonConvertClick);
			// 
			// buttonCopy
			// 
			this.buttonCopy.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.buttonCopy.Location = new System.Drawing.Point(713, 342);
			this.buttonCopy.Name = "buttonCopy";
			this.buttonCopy.Size = new System.Drawing.Size(149, 35);
			this.buttonCopy.TabIndex = 7;
			this.buttonCopy.Text = "Copy";
			this.buttonCopy.UseVisualStyleBackColor = false;
			this.buttonCopy.Click += new System.EventHandler(this.ButtonCopyClick);
			// 
			// labelPrint
			// 
			this.labelPrint.Location = new System.Drawing.Point(472, 246);
			this.labelPrint.Name = "labelPrint";
			this.labelPrint.Size = new System.Drawing.Size(224, 23);
			this.labelPrint.TabIndex = 8;
			this.labelPrint.Text = "Message:";
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.CadetBlue;
			this.button1.Location = new System.Drawing.Point(713, 500);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(149, 38);
			this.button1.TabIndex = 9;
			this.button1.Text = "C l e a r   T e x t";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// labelSymbolsModifies
			// 
			this.labelSymbolsModifies.Location = new System.Drawing.Point(472, 541);
			this.labelSymbolsModifies.Name = "labelSymbolsModifies";
			this.labelSymbolsModifies.Size = new System.Drawing.Size(224, 23);
			this.labelSymbolsModifies.TabIndex = 10;
			this.labelSymbolsModifies.Text = "Symbols modified";
			// 
			// buttonViewUnicode
			// 
			this.buttonViewUnicode.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.buttonViewUnicode.Location = new System.Drawing.Point(713, 205);
			this.buttonViewUnicode.Name = "buttonViewUnicode";
			this.buttonViewUnicode.Size = new System.Drawing.Size(149, 38);
			this.buttonViewUnicode.TabIndex = 11;
			this.buttonViewUnicode.Text = "View Code";
			this.buttonViewUnicode.UseVisualStyleBackColor = false;
			this.buttonViewUnicode.Click += new System.EventHandler(this.ButtonViewUnicodeClick);
			// 
			// textBoxViewUnicode
			// 
			this.textBoxViewUnicode.Location = new System.Drawing.Point(713, 249);
			this.textBoxViewUnicode.Name = "textBoxViewUnicode";
			this.textBoxViewUnicode.Size = new System.Drawing.Size(61, 20);
			this.textBoxViewUnicode.TabIndex = 12;
			this.textBoxViewUnicode.TextChanged += new System.EventHandler(this.TextBoxViewUnicodeTextChanged);
			// 
			// labelUnicodeInfo
			// 
			this.labelUnicodeInfo.Location = new System.Drawing.Point(780, 249);
			this.labelUnicodeInfo.Name = "labelUnicodeInfo";
			this.labelUnicodeInfo.Size = new System.Drawing.Size(82, 58);
			this.labelUnicodeInfo.TabIndex = 13;
			this.labelUnicodeInfo.Text = "Code info";
			// 
			// checkBoxRemoveDoubleSpace
			// 
			this.checkBoxRemoveDoubleSpace.Location = new System.Drawing.Point(713, 170);
			this.checkBoxRemoveDoubleSpace.Name = "checkBoxRemoveDoubleSpace";
			this.checkBoxRemoveDoubleSpace.Size = new System.Drawing.Size(149, 18);
			this.checkBoxRemoveDoubleSpace.TabIndex = 15;
			this.checkBoxRemoveDoubleSpace.Text = "Remove double space";
			this.checkBoxRemoveDoubleSpace.UseVisualStyleBackColor = true;
			this.checkBoxRemoveDoubleSpace.CheckedChanged += new System.EventHandler(this.CheckBoxRemoveDoubleSpaceCheckedChanged);
			// 
			// checkBoxToUpperCase
			// 
			this.checkBoxToUpperCase.Location = new System.Drawing.Point(713, 113);
			this.checkBoxToUpperCase.Name = "checkBoxToUpperCase";
			this.checkBoxToUpperCase.Size = new System.Drawing.Size(149, 24);
			this.checkBoxToUpperCase.TabIndex = 16;
			this.checkBoxToUpperCase.Text = "To Upper Case";
			this.checkBoxToUpperCase.UseVisualStyleBackColor = true;
			this.checkBoxToUpperCase.CheckedChanged += new System.EventHandler(this.CheckBoxToUpperCaseCheckedChanged);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(903, 573);
			this.Controls.Add(this.checkBoxToUpperCase);
			this.Controls.Add(this.checkBoxRemoveDoubleSpace);
			this.Controls.Add(this.labelUnicodeInfo);
			this.Controls.Add(this.textBoxViewUnicode);
			this.Controls.Add(this.buttonViewUnicode);
			this.Controls.Add(this.labelSymbolsModifies);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.labelPrint);
			this.Controls.Add(this.buttonCopy);
			this.Controls.Add(this.buttonConvert);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.richTextBoxLatinLetters);
			this.Controls.Add(this.richTextBoxSpecialLetters);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MainForm";
			this.Text = "Latin Converter";
			this.Load += new System.EventHandler(this.MainFormLoad);
			this.contextMenuStrip1.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
