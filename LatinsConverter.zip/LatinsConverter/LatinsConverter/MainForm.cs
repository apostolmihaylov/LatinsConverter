﻿/*
 * Created by SharpDevelop.
 * User: root
 * Date: 1/8/2021
 * Time: 11:24 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text;

namespace LatinsConverter
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	/// 
	public partial class MainForm : Form
	{
		public char lastChar = ' ';
		public string check = string.Empty;
		public string toUpperLatinText = string.Empty;
		public bool isClickToUpper = false;
		public int countMoreSpaces = 0;
		//public int countAllSymbols = 0;
		public StringBuilder sbSpecialSymbols = new StringBuilder();
		public StringBuilder sbLatinsSymbols = new StringBuilder();
		
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void ButtonConvertClick(object sender, EventArgs e)
		{
			sbLatinsSymbols = sbLatinsSymbols.Clear();
			sbSpecialSymbols = sbSpecialSymbols.Clear();
			checkBoxToUpperCase.Checked = false;
			checkBoxRemoveDoubleSpace.Checked = false;
			
			string[] textArray = richTextBoxSpecialLetters.Text.Split();
			string text = richTextBoxSpecialLetters.Text;
			
			List<string> wordsModifiedsList = new List<string>();
			List<int> differentSymbolsList = new List<int>();
			int counterSymbolsModifies = 0;
			int countAllSymbols = 0;
			char currentSymbol = ' ';
			char lastCharacter = ' ';
			bool specialSymbol = false;
			//bool isWordWithSpecialSymbols = false;
			
			//for (int j = 0; j < textArray.Length; j++) {
				
				//string currentWord = textArray[j];
				
//				if (checkBoxToUpperCase.Checked) {
//					currentWord = currentWord.ToUpper();
//				}
//				else{
//					currentWord = textArray[j];
//				}
				
				for (int i = 0; i < text.Length; i++) {	//< currentWord.Length
				
					//currentSymbol = currentWord[i];
					currentSymbol = text[i];

					countAllSymbols++;
					
					if (currentSymbol == '\'') {
						counterSymbolsModifies++;
						specialSymbol = true;
						//continue;
					} else if (currentSymbol == '”' || currentSymbol == '„' || currentSymbol == '\u201C') {
						//sbSpecialSymbols.Append('"');
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == '\u0027') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == '\u0091') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == '\u0092') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == '\u05F3') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == '\u2018') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == '\u2019') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == '\uFF07') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ă') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ă') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ç') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ç') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Č') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'č') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ď') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ď') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ĺ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ĺ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ľ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ľ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ň') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ň') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ŕ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ŕ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Š') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'š') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ť') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ť') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ł') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ł') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ľ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ľ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ž') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ž') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ü') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ů') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ů') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ű') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ű') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'â') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ä') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'à') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'å') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'é') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ê') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ë') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'è') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ï') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'î') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ì') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ä') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Å') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'É') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ô') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ö') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ò') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'û') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ù') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ÿ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ö') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ü') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ƒ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'á') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'í') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ó') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ú') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ñ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ñ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Á') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Â') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'À') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ã') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ą') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ã') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ą') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ð') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ê') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ê') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ë') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'È') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ı') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Í') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Î') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ï') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ì') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ś') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ś') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ć') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ć') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ź') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ź') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ń') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ń') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ż') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ż') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ş') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ş') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ß') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ó') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ô') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ò') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'õ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ő') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ő') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ţ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ţ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ř') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ř') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Õ') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ú') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Û') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ù') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'ý') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else if (currentSymbol == 'Ý') {
						counterSymbolsModifies++;
						specialSymbol = true;
					} else {
						specialSymbol = false;
					}
				
					if (specialSymbol == true) {
					
					//isWordWithSpecialSymbols = true;
					
					differentSymbolsList.Add(i);
					
					Font fnt = new Font("Verdana", 8F, FontStyle.Bold, GraphicsUnit.Point);
					richTextBoxSpecialLetters.Select(countAllSymbols - 1, 1);
					
					richTextBoxSpecialLetters.SelectionFont = fnt;
					//richTextBoxSpecialLetters.SelectionColor = Color.CadetBlue;
					richTextBoxSpecialLetters.SelectionColor = Color.Red;
					}
				}
				
				//if (isWordWithSpecialSymbols == true) {
					
					//wordsModifiedsList.Add(currentWord);

					//int spaces = wordsModifiedsList.Count;
					
					//using
					//Font fnt = new Font("Verdana", 8F, FontStyle.Bold, GraphicsUnit.Point);

					//if (richTextBoxSpecialLetters.Find(word) >= 0) {
							
					//my1stPosition = richTextBoxSpecialLetters.Find(word);
					//richTextBoxSpecialLetters.SelectionStart = my1stPosition;
					//char firstChar = word[0];
					
//					//using
//					int index = richTextBoxSpecialLetters.Text.IndexOf(currentWord);
//					int length = currentWord.Length;
							
					//richTextBoxSpecialLetters.SelectedText = word;
					//richTextBoxSpecialLetters.SelectionLength = word.Length;
					
					//using
//					for (int i = 0; i < differentSymbolsList.Count; i++) {
//					richTextBoxSpecialLetters.Select(differentSymbolsList[i], 1);
//					
//					//richTextBoxSpecialLetters.Select(index, length);
//					richTextBoxSpecialLetters.SelectionFont = fnt;
//					richTextBoxSpecialLetters.SelectionColor = Color.CadetBlue;
//					}
					
					//using
//					richTextBoxSpecialLetters.Select(countAllSymbols, 1);
//					
//					//richTextBoxSpecialLetters.Select(index, length);
//					richTextBoxSpecialLetters.SelectionFont = fnt;
//					richTextBoxSpecialLetters.SelectionColor = Color.CadetBlue;
				//}
				//isWordWithSpecialSymbols = false;
			//}
			//richTextBoxLatinLetters.Text = sb.ToString();
			// ------------------------------------------------------------------------------------------
			string word1 = richTextBoxSpecialLetters.Text;
			
			for (int i = 0; i < word1.Length; i++) {
				
				currentSymbol = word1[i];
			
				if (currentSymbol == '’' || currentSymbol == '\'') {
					//counterSymbolsModifies++;
					specialSymbol = true;
					//continue;
				} else if (currentSymbol == '”' || currentSymbol == '„' || currentSymbol == '\u201C') {
					sbSpecialSymbols.Append('"');
					specialSymbol = true;
				} else if (currentSymbol == 'Ç') {
					sbSpecialSymbols.Append("C");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ć') {
					sbSpecialSymbols.Append("C");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ç') {
					sbSpecialSymbols.Append("c");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ć') {
					sbSpecialSymbols.Append("c");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Č') {
					sbSpecialSymbols.Append("C");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'č') {
					sbSpecialSymbols.Append("c");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ď') {
					sbSpecialSymbols.Append("D");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ď') {
					sbSpecialSymbols.Append("d");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Đ') {
					sbSpecialSymbols.Append("D");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'đ') {
					sbSpecialSymbols.Append("d");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ĺ') {
					sbSpecialSymbols.Append("L");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ĺ') {
					sbSpecialSymbols.Append("l");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ľ') {
					sbSpecialSymbols.Append("L");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ľ') {
					sbSpecialSymbols.Append("l");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ň') {
					sbSpecialSymbols.Append("N");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ń') {
					sbSpecialSymbols.Append("N");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ń') {
					sbSpecialSymbols.Append("n");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ň') {
					sbSpecialSymbols.Append("n");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ŕ') {
					sbSpecialSymbols.Append("R");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ŕ') {
					sbSpecialSymbols.Append("r");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ř') {
					sbSpecialSymbols.Append("R");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ř') {
					sbSpecialSymbols.Append("r");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Š') {
					sbSpecialSymbols.Append("S");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ś') {
					sbSpecialSymbols.Append("S");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ş') {
					sbSpecialSymbols.Append("S");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'š') {
					sbSpecialSymbols.Append("s");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ś') {
					sbSpecialSymbols.Append("s");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ş') {
					sbSpecialSymbols.Append("s");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ť') {
					sbSpecialSymbols.Append("T");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ť') {
					sbSpecialSymbols.Append("t");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ţ') {
					sbSpecialSymbols.Append("T");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ţ') {
					sbSpecialSymbols.Append("t");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ž') {
					sbSpecialSymbols.Append("Z");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ź') {
					sbSpecialSymbols.Append("Z");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ż') {
					sbSpecialSymbols.Append("Z");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ž') {
					sbSpecialSymbols.Append("z");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ż') {
					sbSpecialSymbols.Append("z");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ź') {
					sbSpecialSymbols.Append("z");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ü') {
					sbSpecialSymbols.Append("u");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ů') {
					sbSpecialSymbols.Append("u");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'â') {
					sbSpecialSymbols.Append("a");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ä') {
					sbSpecialSymbols.Append("a");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'à') {
					sbSpecialSymbols.Append("a");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'å') {
					sbSpecialSymbols.Append("a");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'é') {
					sbSpecialSymbols.Append("e");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ê') {
					sbSpecialSymbols.Append("e");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ë') {
					sbSpecialSymbols.Append("e");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'è') {
					sbSpecialSymbols.Append("e");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ï') {
					sbSpecialSymbols.Append("i");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'î') {
					sbSpecialSymbols.Append("i");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ì') {
					sbSpecialSymbols.Append("i");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ä') {
					sbSpecialSymbols.Append("A");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Å') {
					sbSpecialSymbols.Append("A");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'É') {
					sbSpecialSymbols.Append("E");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ô') {
					sbSpecialSymbols.Append("o");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ö') {
					sbSpecialSymbols.Append("o");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ò') {
					sbSpecialSymbols.Append("o");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'û') {
					sbSpecialSymbols.Append("u");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ù') {
					sbSpecialSymbols.Append("u");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ÿ') {
					sbSpecialSymbols.Append("y");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ö') {
					sbSpecialSymbols.Append("O");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ü') {
					sbSpecialSymbols.Append("U");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ű') {
					sbSpecialSymbols.Append("U");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ű') {
					sbSpecialSymbols.Append("u");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ů') {
					sbSpecialSymbols.Append("U");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ą') {
					sbSpecialSymbols.Append("A");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ą') {
					sbSpecialSymbols.Append("a");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ł') {
					sbSpecialSymbols.Append("L");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ł') {
					sbSpecialSymbols.Append("l");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ƒ') {
					sbSpecialSymbols.Append("f");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'á') {
					sbSpecialSymbols.Append("a");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ă') {
					sbSpecialSymbols.Append("a");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'í') {
					sbSpecialSymbols.Append("i");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ó') {
					sbSpecialSymbols.Append("o");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ú') {
					sbSpecialSymbols.Append("u");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ñ') {
					sbSpecialSymbols.Append("n");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ñ') {
					sbSpecialSymbols.Append("N");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Á') {
					sbSpecialSymbols.Append("A");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Â') {
					sbSpecialSymbols.Append("A");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ă') {
					sbSpecialSymbols.Append("A");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'À') {
					sbSpecialSymbols.Append("A");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ã') {
					sbSpecialSymbols.Append("A");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ã') {
					sbSpecialSymbols.Append("a");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ð') {
					sbSpecialSymbols.Append("D");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ê') {
					sbSpecialSymbols.Append("E");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ě') {
					sbSpecialSymbols.Append("E");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ě') {
					sbSpecialSymbols.Append("e");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ę') {
					sbSpecialSymbols.Append("E");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ę') {
					sbSpecialSymbols.Append("e");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ë') {
					sbSpecialSymbols.Append("E");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'È') {
					sbSpecialSymbols.Append("E");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ı') {
					sbSpecialSymbols.Append("i");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Í') {
					sbSpecialSymbols.Append("I");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Î') {
					sbSpecialSymbols.Append("I");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ï') {
					sbSpecialSymbols.Append("I");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ì') {
					sbSpecialSymbols.Append("I");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ß') {
					sbSpecialSymbols.Append("B");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ó') {
					sbSpecialSymbols.Append("O");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ô') {
					sbSpecialSymbols.Append("O");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ò') {
					sbSpecialSymbols.Append("O");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'õ') {
					sbSpecialSymbols.Append("o");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Õ') {
					sbSpecialSymbols.Append("O");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ő') {
					sbSpecialSymbols.Append("O");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ő') {
					sbSpecialSymbols.Append("o");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ú') {
					sbSpecialSymbols.Append("U");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Û') {
					sbSpecialSymbols.Append("U");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ù') {
					sbSpecialSymbols.Append("U");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'ý') {
					sbSpecialSymbols.Append("y");
					//counterSymbolsModifies++;
					specialSymbol = true;
				} else if (currentSymbol == 'Ý') {
					sbSpecialSymbols.Append("Y");
					//counterSymbolsModifies++;
					specialSymbol = true;
				}
				
				//Convert space with different unicode to normal space 

				else if (
					(currentSymbol == '\u00A0') || (currentSymbol == '\u1680') || (currentSymbol == '\u2000') || (currentSymbol == '\u2001') || (currentSymbol == '\u2002') || (currentSymbol == '\u2003')
					|| (currentSymbol == '\u2004') || (currentSymbol == '\u2005') || (currentSymbol == '\u2006') || (currentSymbol == '\u2007') || (currentSymbol == '\u2008') || (currentSymbol == '\u2009')
					|| (currentSymbol == '\u200A') || (currentSymbol == '\u202F') || (currentSymbol == '\u205F') || (currentSymbol == '\u3000') || (currentSymbol == '\uFEFF')) {
					
					sbSpecialSymbols.Append('\u0020');// Standart space
					counterSymbolsModifies++;
					//labelPrint.Text = "Message: Space with different Unicode";
				} 
				// Append all symbols except special symbols and different space
				else {
					specialSymbol = false;
					sbSpecialSymbols.Append(currentSymbol);
				}
				lastCharacter = currentSymbol;
			}
			// ------------------------------------------------------------------------------------------
			richTextBoxLatinLetters.Text = sbSpecialSymbols.ToString();
			//labelSymbolsModifies.Text = counterSymbolsModifies / wordsModifiedsList.Count + " symbols modified. All characters: " + countAllSymbols / wordsModifiedsList.Count;
			labelSymbolsModifies.Text = counterSymbolsModifies + " symbols modified. All characters: " + countAllSymbols;
			//labelPrint.Text = "Message: Mark only unique words.";
		}
		void ButtonCopyClick(object sender, EventArgs e)
		{
			if (richTextBoxLatinLetters.Text.Length > 0) {
				
				Clipboard.SetText(richTextBoxLatinLetters.Text);
			
				richTextBoxLatinLetters.Focus();
				richTextBoxLatinLetters.SelectAll();
			}
		}
		void Button1Click(object sender, EventArgs e)// Clear Text
		{
			richTextBoxSpecialLetters.Text = "";
			richTextBoxLatinLetters.Text = "";
			labelSymbolsModifies.Text = "zero symbols modified.";
			textBoxViewUnicode.Text = "";
			labelUnicodeInfo.Text = "Code info";
			sbLatinsSymbols = sbLatinsSymbols.Clear();
			sbSpecialSymbols = sbSpecialSymbols.Clear();
		}
		void RichTextBoxSpecialLettersTextChanged(object sender, EventArgs e)
		{

		}
		void PasteToolStripMenuItemClick(object sender, EventArgs e)
		{
			string xx = Clipboard.GetText();
			
			richTextBoxSpecialLetters.Text = richTextBoxSpecialLetters.Text.Insert(richTextBoxSpecialLetters.SelectionStart, xx);
		}
		void ButtonViewUnicodeClick(object sender, EventArgs e)
		{
			string selectSymbol = richTextBoxSpecialLetters.SelectedText;
			
			// Check for selection 
			if (selectSymbol.Length == 1) {
				
				char symbol = selectSymbol[0];
				int unicodeNumber = symbol;
				
				if (unicodeNumber == 9) {
					labelUnicodeInfo.Text = "Tab";
				} else if (unicodeNumber == 10) {
					labelUnicodeInfo.Text = "New Line";
				} else if (unicodeNumber == 32) {
					labelUnicodeInfo.Text = "Standart Space";
				} else {
					labelUnicodeInfo.Text = symbol.ToString();
				}
				if (symbol == '\u00A0' || symbol == '\u1680' || symbol == '\u180E' || symbol == '\u180e' || symbol == '\u2000' || symbol == '\u2001' || symbol == '\u2002' || symbol == '\u2003' || symbol == '\u2004' || symbol == '\u2005' || symbol == '\u2006' || symbol == '\u2007' || symbol == '\u2008' || symbol == '\u2009' || symbol == '\u200A' || symbol == '\u200B' || symbol == '\u202F' || symbol == '\u205F' || symbol == '\u3000' || symbol == '\uFEFF') {
					labelUnicodeInfo.Text = "Different Space";
				}
				textBoxViewUnicode.Text = unicodeNumber.ToString();
			} else {
				labelUnicodeInfo.Text = "Select One Character!";
			}
		}
		void TextBoxViewUnicodeTextChanged(object sender, EventArgs e)
		{
	
		}
		void MainFormLoad(object sender, EventArgs e)
		{
	
		}
		void CheckBoxRemoveDoubleSpaceCheckedChanged(object sender, EventArgs e)
		{
			string inputText = richTextBoxLatinLetters.Text;
			
			if (checkBoxRemoveDoubleSpace.Checked) {
				
				for (int i = 0; i < inputText.Length; i++) {
				
					char currentChar = inputText[i];
				
					if (currentChar == '\u0020' && lastChar == '\u0020' && i != 0) {
						countMoreSpaces++;
						continue;
					} 
				
					sbLatinsSymbols.Append(currentChar);
				
					lastChar = currentChar;
				}
				richTextBoxLatinLetters.Text = sbLatinsSymbols.ToString();
			} else {
				countMoreSpaces = 0;
				sbLatinsSymbols = sbLatinsSymbols.Clear();
				if (checkBoxToUpperCase.Checked) {
					toUpperLatinText = sbSpecialSymbols.ToString();
					toUpperLatinText = toUpperLatinText.ToUpper();
				} else {
					toUpperLatinText = sbSpecialSymbols.ToString();
				}
				richTextBoxLatinLetters.Text = toUpperLatinText;
				//richTextBoxLatinLetters.Text = inputText;
			}
			labelPrint.Text = "Message: " + countMoreSpaces + " more spaces.";
		}
		void CheckBoxToUpperCaseCheckedChanged(object sender, EventArgs e)
		{
			string text = richTextBoxLatinLetters.Text;
			
			toUpper(ref text);
		}

		void toUpper(ref string text)
		{
			if (checkBoxToUpperCase.Checked) {
				text = text.ToUpper();
			} else {
				text = sbSpecialSymbols.ToString();
			}
			richTextBoxLatinLetters.Text = text;
		}
	}
}
